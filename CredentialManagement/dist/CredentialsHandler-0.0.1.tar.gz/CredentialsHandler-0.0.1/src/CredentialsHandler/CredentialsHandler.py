#!/bin/python3
"""
  ____              _            _   _       _
 / ___|_ __ ___  __| | ___ _ __ | |_(_) __ _| |___
| |   | '__/ _ \/ _` |/ _ \ '_ \| __| |/ _` | / __|
| |___| | |  __/ (_| |  __/ | | | |_| | (_| | \__ \
 \____|_|  \___|\__,_|\___|_| |_|\__|_|\__,_|_|___/

 _   _                 _ _ _
| | | | __ _ _ __   __| | (_)_ __   __ _
| |_| |/ _` | '_ \ / _` | | | '_ \ / _` |
|  _  | (_| | | | | (_| | | | | | | (_| |
|_| |_|\__,_|_| |_|\__,_|_|_|_| |_|\__, |
                                    |___/
"""


import argparse
import sqlite3
import logging
from CryptographyMethods import *


def BuildPrivateKey(keyfile):
  """ This function uses a given file as the base to re-build the key
  used to encrypt private credentials known to the administrator. """
  logging.getLogger()
  logging.debug(f"Retrieving build key from {keyfile}\n")

  cryptograph = CryptographyMethods()

  with open(keyfile, "r") as privkey:
    PRIVKEY = privkey.read().split("\n")[1]

  return cryptograph.BuildKey(PRIVKEY)


def CredentialLocker( keyfile, credabase, credential,
                      platform, singleKey=True ):
  """ This function will add a new credential to the database.
  If the singleKey argument is true then it just encrypts the value of
  the credential argument at face value; but if it is set to false
  then it is assumed that the argument is a dictionary containing 'key'
  and 'secret' entries. """
  logging.getLogger()
  logging.debug(f"Connecting to credential database at {credabase}\n")
  connection = sqlite3.connect(credabase); cursor = connection.cursor()

  cryptograph = CryptographyMethods()

  if singleKey:
    logging.info("Single-Key credential selected.")
    secret = cryptograph\
               .Encryption( BuildPrivateKey(keyfile),
                            credential                )

    logging.info("Adding new credential to the database.")
    cursor.execute( "ALTER credentials "\
                    "ADD ? BYTES;",
                    (platform.lower,)     )

    cursor.execute( "UPDATE credentials SET ?=? "\
                    "WHERE username='admin';"\
                    .format( platform,
                             secret    )           )
  else:

    logging.info("Multi-Key credentials selected.")

    # Create the key.
    logging.info("Adding new key to the database.")
    credential['key'] = cryptograph\
                          .Encryption( BuildPrivateKey(keyfile),
                                       credential['key']         )
    # Create a column for the key.
    cursor.execute( "ALTER credentials "
                    "ADD {} BYTES"\
                    .format(f"{platform}_key") )
    # Add key.
    cursor.execute( "UPDATE credentials SET ?=? "\
                    "WHERE username='admin';"\
                    .format( f"{platform}_key",
                             credential['key']))

    # Create the secret.
    logging.info("Adding new secret to the database.")
    credential['secret'] = cryptograph\
                             .Encryption( BuildPrivateKey(keyfile),
                                          credential['secret']      )
    # Create a column for the key.
    cursor.execute( "ALTER credentials "
                    "ADD {} BYTES"\
                    .format(f"{platform}_secret") )
    # Add secret.
    cursor.execute( "UPDATE credentials SET ?=? "\
                    "WHERE username='admin';"\
                    .format( f"{platform}_secret",
                             credential['secret']))

  logging.info("Database write done!\n")
  return connection.commit()


def CredentialUnlocker( keyfile, credential ):
  """ This function simply unencrypts a given bytestring,
  assuming the correct keyfile is supplied. """
  logging.getLogger()
  logging.info("Unlocking credentials.\n")

  cryptograph = CryptographyMethods()

  return cryptograph\
           .Decryption( BuildPrivateKey(keyfile),
                        credential                )\
           .decode()


def SingleKeyAPICredentials( platform, credabase, keyfile ):
  """ This function retrieves the key for any API that only requires a single
  credential for validation. """
  logging.getLogger()

  logging.debug(f"Connecting to credential database at {credabase}\n")
  connection = sqlite3.connect(credabase); cursor = connection.cursor()

  logging.info(f"Retrieving single-key credentials for {platform}.\n")
  secrets = cursor.execute( "SELECT ? FROM credentials "\
                            "WHERE username = 'admin'",
                            (platform,)                   ).fetchall()[0]

  return CredentialUnlocker(keyfile, secrets[0])


def MultiKeyAPICredentials( platform, credabase, keyfile ):
  """ This function retrieves the multi-key authentication tokens for any API
  that requires more than one credential to validate sign-on. """
  logging.getLogger()

  logging.debug(f"Connecting to credential database at {credabase}\n")
  connection = sqlite3.connect(credabase); cursor = connection.cursor()

  logging.info(f"Retrieving multi-key credentials for {platform}.\n")
  secrets = cursor.execute( "SELECT {}, {} FROM credentials "\
                            "WHERE username = 'admin';"\
                              .format( f"{platform}_key",
                                       f"{platform}_secret" ) )\
                  .fetchall()[0]

  credentials = { "key": CredentialUnlocker(keyfile, secrets[0]),
                  "secret": CredentialUnlocker(keyfile, secrets[1]) }

  return credentials


if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  parser.add_argument("--credabase")
  parser.add_argument("--keyfile")
  parser.add_argument("--platform")
  parser.add_argument("--multi-key", action="store_true")
  arguments = parser.parse_args()

  if arguments.credabase: credabase = arguments.credabase
  if arguments.keyfile: keyfile = arguments.keyfile
  if arguments.platform: platform = arguments.platform
  if arguments.multikey: MultiKeyAPICredentials(platform, credabase, keyfile)
  else: SingleKeyAPICredential(platform, credabase, keyfile)
